package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Platform
import com.example.data.repository.ThemeMode
import com.example.ui.components.CreateCollectionDialog
import com.example.ui.components.LinkDetailSheet
import com.example.ui.components.ManualAddLinkDialog
import com.example.ui.components.SaveSharedLinkDialog
import com.example.ui.screens.CollectionsScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LinkVaultTheme
import com.example.ui.viewmodel.LinkVaultViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LinkVaultViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle initial share intent if launched via Android Sharesheet
        handleIncomingIntent(intent)

        setContent {
            val themeMode by viewModel.preferences.themeMode.collectAsStateWithLifecycle()
            val amoledMode by viewModel.preferences.amoledMode.collectAsStateWithLifecycle()
            val dynamicColor by viewModel.preferences.dynamicColor.collectAsStateWithLifecycle()

            val isDark = when (themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            LinkVaultTheme(
                darkTheme = isDark,
                amoledMode = amoledMode,
                dynamicColor = dynamicColor
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LinkVaultApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type

        if (Intent.ACTION_SEND == action && type != null) {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                ?: intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                ?: intent.dataString

            if (!sharedText.isNullOrBlank()) {
                val urls = Platform.extractUrls(sharedText)
                if (urls.isNotEmpty()) {
                    viewModel.handleIncomingMultipleUrls(urls)
                } else {
                    viewModel.handleIncomingUrl(sharedText)
                }
            }
        } else if (Intent.ACTION_SEND_MULTIPLE == action && type != null) {
            val textList = intent.getStringArrayListExtra(Intent.EXTRA_TEXT)
            if (!textList.isNullOrEmpty()) {
                val allUrls = textList.flatMap { Platform.extractUrls(it) }
                if (allUrls.isNotEmpty()) {
                    viewModel.handleIncomingMultipleUrls(allUrls)
                }
            } else {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!sharedText.isNullOrBlank()) {
                    val urls = Platform.extractUrls(sharedText)
                    viewModel.handleIncomingMultipleUrls(urls)
                }
            }
        }
    }
}

@Composable
fun LinkVaultApp(viewModel: LinkVaultViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val collections by viewModel.collections.collectAsStateWithLifecycle()
    val saveDialogState by viewModel.saveDialogState.collectAsStateWithLifecycle()
    val selectedDetailLink by viewModel.selectedLinkForDetails.collectAsStateWithLifecycle()
    val createCollectionDialogVisible by viewModel.createCollectionDialogVisible.collectAsStateWithLifecycle()
    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    var showManualAddDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Display snackbar with undo support
    LaunchedEffect(snackbarMsg) {
        if (!snackbarMsg.isNullOrBlank()) {
            val isDelete = snackbarMsg?.startsWith("Deleted") == true
            val result = snackbarHostState.showSnackbar(
                message = snackbarMsg!!,
                actionLabel = if (isDelete) "Undo" else null,
                duration = if (isDelete) SnackbarDuration.Long else SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed && isDelete) {
                viewModel.undoDelete()
            }
            viewModel.clearSnackbarMessage()
        }
    }

    // Predictive back handling
    BackHandler(enabled = currentTab != 0) {
        viewModel.setCurrentTab(0)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!isWide) {
                    NavigationBar(
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("bottom_nav_bar")
                    ) {
                        NavigationBarItem(
                            selected = currentTab == 0,
                            onClick = { viewModel.setCurrentTab(0) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 0) Icons.Default.Home else Icons.Outlined.Home,
                                    contentDescription = "Home"
                                )
                            },
                            label = { Text("Home") },
                            modifier = Modifier.testTag("nav_item_home")
                        )
                        NavigationBarItem(
                            selected = currentTab == 1,
                            onClick = { viewModel.setCurrentTab(1) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 1) Icons.Default.Folder else Icons.Outlined.Folder,
                                    contentDescription = "Collections"
                                )
                            },
                            label = { Text("Collections") },
                            modifier = Modifier.testTag("nav_item_collections")
                        )
                        NavigationBarItem(
                            selected = currentTab == 2,
                            onClick = { viewModel.setCurrentTab(2) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 2) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                    contentDescription = "Favorites"
                                )
                            },
                            label = { Text("Favorites") },
                            modifier = Modifier.testTag("nav_item_favorites")
                        )
                        NavigationBarItem(
                            selected = currentTab == 3,
                            onClick = { viewModel.setCurrentTab(3) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 3) Icons.Default.Settings else Icons.Outlined.Settings,
                                    contentDescription = "Settings"
                                )
                            },
                            label = { Text("Settings") },
                            modifier = Modifier.testTag("nav_item_settings")
                        )
                    }
                }
            }
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // NavigationRail for tablets / wide screens
                if (isWide) {
                    NavigationRail(
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("nav_rail")
                    ) {
                        NavigationRailItem(
                            selected = currentTab == 0,
                            onClick = { viewModel.setCurrentTab(0) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 0) Icons.Default.Home else Icons.Outlined.Home,
                                    contentDescription = "Home"
                                )
                            },
                            label = { Text("Home") }
                        )
                        NavigationRailItem(
                            selected = currentTab == 1,
                            onClick = { viewModel.setCurrentTab(1) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 1) Icons.Default.Folder else Icons.Outlined.Folder,
                                    contentDescription = "Collections"
                                )
                            },
                            label = { Text("Collections") }
                        )
                        NavigationRailItem(
                            selected = currentTab == 2,
                            onClick = { viewModel.setCurrentTab(2) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 2) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                    contentDescription = "Favorites"
                                )
                            },
                            label = { Text("Favorites") }
                        )
                        NavigationRailItem(
                            selected = currentTab == 3,
                            onClick = { viewModel.setCurrentTab(3) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == 3) Icons.Default.Settings else Icons.Outlined.Settings,
                                    contentDescription = "Settings"
                                )
                            },
                            label = { Text("Settings") }
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        0 -> HomeScreen(
                            viewModel = viewModel,
                            onOpenAddLink = { showManualAddDialog = true }
                        )
                        1 -> CollectionsScreen(viewModel = viewModel)
                        2 -> FavoritesScreen(viewModel = viewModel)
                        3 -> SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    // Save Confirmation Dialog (Opened when links are shared or added)
    saveDialogState?.let { dialogState ->
        SaveSharedLinkDialog(
            state = dialogState,
            collections = collections,
            onUpdateState = { transform -> viewModel.updateSaveDialogState(transform) },
            onConfirm = { viewModel.confirmSaveDialog() },
            onDismiss = { viewModel.dismissSaveDialog() }
        )
    }

    // Link Detail Bottom Sheet
    selectedDetailLink?.let { detailLink ->
        LinkDetailSheet(
            link = detailLink,
            collections = collections,
            onDismiss = { viewModel.closeLinkDetails() },
            onToggleFavorite = { viewModel.toggleFavorite(detailLink) },
            onUpdateLink = { updated -> viewModel.updateLinkDetails(updated) },
            onDeleteLink = { viewModel.deleteLink(detailLink) }
        )
    }

    // Create Collection Dialog
    if (createCollectionDialogVisible) {
        CreateCollectionDialog(
            onDismiss = { viewModel.setCreateCollectionDialogVisible(false) },
            onConfirm = { name, colorHex, iconName ->
                viewModel.createCollection(name, colorHex, iconName)
            }
        )
    }

    // Manual Add Dialog
    if (showManualAddDialog) {
        ManualAddLinkDialog(
            onDismiss = { showManualAddDialog = false },
            onSubmitUrl = { url ->
                showManualAddDialog = false
                viewModel.handleIncomingUrl(url)
            }
        )
    }
}
