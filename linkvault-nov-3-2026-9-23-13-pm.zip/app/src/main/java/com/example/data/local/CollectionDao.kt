package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CollectionItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CollectionDao {
    @Query("SELECT * FROM collections ORDER BY createdAt ASC")
    fun getAllCollectionsFlow(): Flow<List<CollectionItem>>

    @Query("SELECT * FROM collections WHERE id = :id LIMIT 1")
    suspend fun getCollectionById(id: Long): CollectionItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollection(collection: CollectionItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollections(collections: List<CollectionItem>)

    @Update
    suspend fun updateCollection(collection: CollectionItem)

    @Delete
    suspend fun deleteCollection(collection: CollectionItem)

    @Query("DELETE FROM collections WHERE id = :id")
    suspend fun deleteCollectionById(id: Long)

    @Query("SELECT * FROM collections ORDER BY createdAt ASC")
    suspend fun getAllCollectionsList(): List<CollectionItem>

    @Query("DELETE FROM collections")
    suspend fun clearAll()
}
