package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "saved_links",
    indices = [
        Index(value = ["url"]),
        Index(value = ["platform"]),
        Index(value = ["isFavorite"]),
        Index(value = ["createdAt"])
    ]
)
data class SavedLink(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val url: String,
    val title: String,
    val description: String? = null,
    val thumbnailUrl: String? = null,
    val platform: String,
    val domain: String,
    val personalNote: String? = null,
    val collectionId: Long? = null,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
