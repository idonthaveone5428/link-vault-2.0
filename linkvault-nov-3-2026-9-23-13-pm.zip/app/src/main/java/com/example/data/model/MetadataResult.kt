package com.example.data.model

data class MetadataResult(
    val url: String,
    val title: String,
    val description: String?,
    val thumbnailUrl: String?,
    val domain: String,
    val platform: Platform
)
