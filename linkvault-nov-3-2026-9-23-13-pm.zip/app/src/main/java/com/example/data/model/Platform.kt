package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.OtherGreen
import com.example.ui.theme.PinterestRed
import com.example.ui.theme.RedditOrange
import com.example.ui.theme.XBlack
import com.example.ui.theme.YouTubeRed
import java.net.URI
import java.util.Locale
import java.util.regex.Pattern

enum class Platform(
    val displayName: String,
    val badgeColor: Color
) {
    INSTAGRAM("Instagram", InstagramPink),
    FACEBOOK("Facebook", FacebookBlue),
    YOUTUBE("YouTube", YouTubeRed),
    REDDIT("Reddit", RedditOrange),
    X("X", XBlack),
    PINTEREST("Pinterest", PinterestRed),
    OTHER("Other", OtherGreen);

    companion object {
        // Regex pattern to extract all web URLs from arbitrary text
        private val URL_PATTERN: Pattern = Pattern.compile(
            "https?://(?:www\\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)",
            Pattern.CASE_INSENSITIVE
        )

        fun extractUrls(text: String?): List<String> {
            if (text.isNullOrBlank()) return emptyList()
            val matcher = URL_PATTERN.matcher(text)
            val urls = mutableListOf<String>()
            while (matcher.find()) {
                val found = matcher.group().trim()
                if (found.isNotEmpty() && !urls.contains(found)) {
                    urls.add(found)
                }
            }
            return urls
        }

        fun extractDomain(rawUrl: String): String {
            return try {
                var clean = rawUrl.trim()
                if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
                    clean = "https://$clean"
                }
                val uri = URI(clean)
                var host = uri.host ?: ""
                if (host.startsWith("www.")) {
                    host = host.substring(4)
                }
                host.lowercase(Locale.ROOT).ifEmpty { "web" }
            } catch (_: Exception) {
                "web"
            }
        }

        fun fromUrl(url: String): Platform {
            val domain = extractDomain(url).lowercase(Locale.ROOT)
            return when {
                domain.contains("instagram.com") -> INSTAGRAM
                domain.contains("facebook.com") || domain.contains("fb.watch") || domain.contains("fb.com") -> FACEBOOK
                domain.contains("youtube.com") || domain.contains("youtu.be") -> YOUTUBE
                domain.contains("reddit.com") || domain.contains("redd.it") -> REDDIT
                domain.contains("twitter.com") || domain.contains("x.com") -> X
                domain.contains("pinterest.com") || domain.contains("pin.it") -> PINTEREST
                else -> OTHER
            }
        }

        fun fromString(name: String?): Platform {
            return entries.find { it.name.equals(name, ignoreCase = true) || it.displayName.equals(name, ignoreCase = true) } ?: OTHER
        }
    }
}
