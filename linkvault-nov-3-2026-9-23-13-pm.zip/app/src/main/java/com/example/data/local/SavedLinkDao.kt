package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SavedLink
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedLinkDao {
    @Query("SELECT * FROM saved_links ORDER BY createdAt DESC")
    fun getAllLinksFlow(): Flow<List<SavedLink>>

    @Query("SELECT * FROM saved_links WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavoritesFlow(): Flow<List<SavedLink>>

    @Query("SELECT * FROM saved_links WHERE platform = :platform ORDER BY createdAt DESC")
    fun getLinksByPlatformFlow(platform: String): Flow<List<SavedLink>>

    @Query("SELECT * FROM saved_links WHERE collectionId = :collectionId ORDER BY createdAt DESC")
    fun getLinksByCollectionFlow(collectionId: Long): Flow<List<SavedLink>>

    @Query("""
        SELECT * FROM saved_links 
        WHERE title LIKE '%' || :query || '%' 
           OR url LIKE '%' || :query || '%' 
           OR domain LIKE '%' || :query || '%' 
           OR personalNote LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
    """)
    fun searchLinksFlow(query: String): Flow<List<SavedLink>>

    @Query("SELECT * FROM saved_links WHERE id = :id LIMIT 1")
    suspend fun getLinkById(id: Long): SavedLink?

    @Query("SELECT * FROM saved_links WHERE url = :url LIMIT 1")
    suspend fun getLinkByUrl(url: String): SavedLink?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLink(link: SavedLink): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLinks(links: List<SavedLink>)

    @Update
    suspend fun updateLink(link: SavedLink)

    @Delete
    suspend fun deleteLink(link: SavedLink)

    @Query("DELETE FROM saved_links WHERE id = :id")
    suspend fun deleteLinkById(id: Long)

    @Query("SELECT COUNT(*) FROM saved_links")
    fun countAllLinks(): Flow<Int>

    @Query("SELECT * FROM saved_links ORDER BY createdAt DESC")
    suspend fun getAllLinksList(): List<SavedLink>

    @Query("DELETE FROM saved_links")
    suspend fun clearAll()
}
