package com.example.data.repository

import com.example.data.local.CollectionDao
import com.example.data.local.SavedLinkDao
import com.example.data.model.CollectionItem
import com.example.data.model.SavedLink
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class LinkRepository(
    private val linkDao: SavedLinkDao,
    private val collectionDao: CollectionDao
) {
    val allLinks: Flow<List<SavedLink>> = linkDao.getAllLinksFlow()
    val favoriteLinks: Flow<List<SavedLink>> = linkDao.getFavoritesFlow()
    val allCollections: Flow<List<CollectionItem>> = collectionDao.getAllCollectionsFlow()
    val totalCount: Flow<Int> = linkDao.countAllLinks()

    fun getLinksByPlatform(platform: String): Flow<List<SavedLink>> {
        return linkDao.getLinksByPlatformFlow(platform)
    }

    fun getLinksByCollection(collectionId: Long): Flow<List<SavedLink>> {
        return linkDao.getLinksByCollectionFlow(collectionId)
    }

    fun searchLinks(query: String): Flow<List<SavedLink>> {
        return linkDao.searchLinksFlow(query)
    }

    suspend fun getLinkById(id: Long): SavedLink? {
        return linkDao.getLinkById(id)
    }

    suspend fun findExistingLink(url: String): SavedLink? {
        return linkDao.getLinkByUrl(url)
    }

    suspend fun saveLink(link: SavedLink): Long {
        return linkDao.insertLink(link)
    }

    suspend fun updateLink(link: SavedLink) {
        linkDao.updateLink(link.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteLink(link: SavedLink) {
        linkDao.deleteLink(link)
    }

    suspend fun deleteLinkById(id: Long) {
        linkDao.deleteLinkById(id)
    }

    suspend fun toggleFavorite(link: SavedLink) {
        linkDao.updateLink(link.copy(isFavorite = !link.isFavorite, updatedAt = System.currentTimeMillis()))
    }

    suspend fun createCollection(name: String, colorHex: String, iconName: String): Long {
        return collectionDao.insertCollection(
            CollectionItem(
                name = name,
                colorHex = colorHex,
                iconName = iconName
            )
        )
    }

    suspend fun updateCollection(collection: CollectionItem) {
        collectionDao.updateCollection(collection)
    }

    suspend fun deleteCollection(collection: CollectionItem) {
        collectionDao.deleteCollection(collection)
    }

    suspend fun clearAllData() {
        linkDao.clearAll()
        collectionDao.clearAll()
    }

    // Export links and collections as JSON string
    suspend fun exportToJson(): String {
        val links = linkDao.getAllLinksList()
        val collections = collectionDao.getAllCollectionsList()

        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val collectionsArray = JSONArray()
        for (c in collections) {
            val cObj = JSONObject()
            cObj.put("id", c.id)
            cObj.put("name", c.name)
            cObj.put("colorHex", c.colorHex)
            cObj.put("iconName", c.iconName)
            cObj.put("createdAt", c.createdAt)
            collectionsArray.put(cObj)
        }
        root.put("collections", collectionsArray)

        val linksArray = JSONArray()
        for (l in links) {
            val lObj = JSONObject()
            lObj.put("url", l.url)
            lObj.put("title", l.title)
            lObj.put("description", l.description ?: "")
            lObj.put("thumbnailUrl", l.thumbnailUrl ?: "")
            lObj.put("platform", l.platform)
            lObj.put("domain", l.domain)
            lObj.put("personalNote", l.personalNote ?: "")
            lObj.put("collectionId", l.collectionId ?: -1L)
            lObj.put("isFavorite", l.isFavorite)
            lObj.put("createdAt", l.createdAt)
            lObj.put("updatedAt", l.updatedAt)
            linksArray.put(lObj)
        }
        root.put("links", linksArray)

        return root.toString(2)
    }

    // Import from JSON string
    suspend fun importFromJson(jsonString: String): Pair<Int, Int> {
        val root = JSONObject(jsonString)
        val collectionsArray = root.optJSONArray("collections")
        var importedCollections = 0
        var importedLinks = 0

        val collectionIdMap = mutableMapOf<Long, Long>()

        if (collectionsArray != null) {
            for (i in 0 until collectionsArray.length()) {
                val cObj = collectionsArray.getJSONObject(i)
                val oldId = cObj.optLong("id", -1L)
                val name = cObj.getString("name")
                val colorHex = cObj.optString("colorHex", "#006399")
                val iconName = cObj.optString("iconName", "folder")
                val createdAt = cObj.optLong("createdAt", System.currentTimeMillis())

                val newId = collectionDao.insertCollection(
                    CollectionItem(
                        name = name,
                        colorHex = colorHex,
                        iconName = iconName,
                        createdAt = createdAt
                    )
                )
                if (oldId != -1L) {
                    collectionIdMap[oldId] = newId
                }
                importedCollections++
            }
        }

        val linksArray = root.optJSONArray("links")
        if (linksArray != null) {
            val linksToInsert = mutableListOf<SavedLink>()
            for (i in 0 until linksArray.length()) {
                val lObj = linksArray.getJSONObject(i)
                val url = lObj.getString("url")
                val title = lObj.getString("title")
                val description = lObj.optString("description").takeIf { it.isNotEmpty() }
                val thumbnailUrl = lObj.optString("thumbnailUrl").takeIf { it.isNotEmpty() }
                val platform = lObj.optString("platform", "Other")
                val domain = lObj.optString("domain", "web")
                val personalNote = lObj.optString("personalNote").takeIf { it.isNotEmpty() }
                val rawCollId = lObj.optLong("collectionId", -1L)
                val mappedCollId = if (rawCollId != -1L) collectionIdMap[rawCollId] else null
                val isFavorite = lObj.optBoolean("isFavorite", false)
                val createdAt = lObj.optLong("createdAt", System.currentTimeMillis())
                val updatedAt = lObj.optLong("updatedAt", System.currentTimeMillis())

                linksToInsert.add(
                    SavedLink(
                        url = url,
                        title = title,
                        description = description,
                        thumbnailUrl = thumbnailUrl,
                        platform = platform,
                        domain = domain,
                        personalNote = personalNote,
                        collectionId = mappedCollId,
                        isFavorite = isFavorite,
                        createdAt = createdAt,
                        updatedAt = updatedAt
                    )
                )
                importedLinks++
            }
            linkDao.insertLinks(linksToInsert)
        }

        return Pair(importedLinks, importedCollections)
    }
}
