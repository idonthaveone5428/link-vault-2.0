package com.example.data.network

import com.example.data.model.MetadataResult
import com.example.data.model.Platform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object MetadataExtractor {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    private val OG_TITLE_PATTERN = Pattern.compile(
        "<meta[^>]+(?:property|name)=[\"'](?:og:title|twitter:title)[\"'][^>]+content=[\"']([^\"']+)[\"']|<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"'](?:og:title|twitter:title)[\"']",
        Pattern.CASE_INSENSITIVE
    )

    private val TITLE_TAG_PATTERN = Pattern.compile(
        "<title[^>]*>([^<]+)</title>",
        Pattern.CASE_INSENSITIVE
    )

    private val OG_IMAGE_PATTERN = Pattern.compile(
        "<meta[^>]+(?:property|name)=[\"'](?:og:image|twitter:image|og:image:url)[\"'][^>]+content=[\"']([^\"']+)[\"']|<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"'](?:og:image|twitter:image|og:image:url)[\"']",
        Pattern.CASE_INSENSITIVE
    )

    private val OG_DESC_PATTERN = Pattern.compile(
        "<meta[^>]+(?:property|name)=[\"'](?:og:description|twitter:description|description)[\"'][^>]+content=[\"']([^\"']+)[\"']|<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"'](?:og:description|twitter:description|description)[\"']",
        Pattern.CASE_INSENSITIVE
    )

    private val YOUTUBE_ID_PATTERN = Pattern.compile(
        "(?:youtu\\.be/|youtube\\.com/(?:embed/|v/|watch\\?v=|watch\\?.+&v=|shorts/))([a-zA-Z0-9_-]{11})"
    )

    suspend fun extract(rawUrl: String): MetadataResult = withContext(Dispatchers.IO) {
        var cleanUrl = rawUrl.trim()
        if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            cleanUrl = "https://$cleanUrl"
        }

        val domain = Platform.extractDomain(cleanUrl)
        val platform = Platform.fromUrl(cleanUrl)

        // Check for YouTube direct thumbnail shortcut
        val ytVideoId = extractYouTubeId(cleanUrl)
        val fallbackYtThumbnail = if (ytVideoId != null) {
            "https://img.youtube.com/vi/$ytVideoId/hqdefault.jpg"
        } else null

        var extractedTitle: String? = null
        var extractedDesc: String? = null
        var extractedImage: String? = fallbackYtThumbnail

        try {
            val request = Request.Builder()
                .url(cleanUrl)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                )
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.5")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body
                    if (responseBody != null) {
                        // Read only up to 256KB to quickly extract head tags
                        val html = responseBody.source().readUtf8(minOf(256 * 1024L, responseBody.contentLength().let { if (it > 0) it else 256 * 1024L }))
                        
                        // Extract Title
                        extractedTitle = matchMetaContent(OG_TITLE_PATTERN, html)
                            ?: matchTag(TITLE_TAG_PATTERN, html)

                        // Extract Description
                        extractedDesc = matchMetaContent(OG_DESC_PATTERN, html)

                        // Extract Image
                        val metaImg = matchMetaContent(OG_IMAGE_PATTERN, html)
                        if (!metaImg.isNullOrBlank()) {
                            extractedImage = resolveUrl(metaImg, cleanUrl)
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Network failure or timeout; proceed with graceful fallbacks
        }

        // Clean up title
        val finalTitle = extractedTitle
            ?.let { decodeHtmlEntities(it).trim() }
            ?.takeIf { it.isNotEmpty() }
            ?: generateFallbackTitle(cleanUrl, domain, platform)

        val finalDesc = extractedDesc
            ?.let { decodeHtmlEntities(it).trim() }
            ?.takeIf { it.isNotEmpty() }

        MetadataResult(
            url = cleanUrl,
            title = finalTitle,
            description = finalDesc,
            thumbnailUrl = extractedImage,
            domain = domain,
            platform = platform
        )
    }

    private fun extractYouTubeId(url: String): String? {
        val matcher = YOUTUBE_ID_PATTERN.matcher(url)
        return if (matcher.find()) matcher.group(1) else null
    }

    private fun matchMetaContent(pattern: Pattern, text: String): String? {
        val matcher = pattern.matcher(text)
        return if (matcher.find()) {
            matcher.group(1) ?: matcher.group(2)
        } else null
    }

    private fun matchTag(pattern: Pattern, text: String): String? {
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group(1) else null
    }

    private fun resolveUrl(rawImg: String, baseUrl: String): String {
        val trimmed = rawImg.trim()
        return when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.startsWith("//") -> "https:$trimmed"
            trimmed.startsWith("/") -> {
                val baseDomain = Platform.extractDomain(baseUrl)
                "https://$baseDomain$trimmed"
            }
            else -> trimmed
        }
    }

    private fun generateFallbackTitle(url: String, domain: String, platform: Platform): String {
        return when (platform) {
            Platform.INSTAGRAM -> "Instagram Post / Reel"
            Platform.FACEBOOK -> "Facebook Video or Post"
            Platform.YOUTUBE -> "YouTube Video"
            Platform.REDDIT -> "Reddit Discussion"
            Platform.X -> "X (Twitter) Post"
            Platform.PINTEREST -> "Pinterest Pin"
            Platform.OTHER -> domain.replaceFirstChar { it.uppercase() } + " Link"
        }
    }

    private fun decodeHtmlEntities(input: String): String {
        return input
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&#39;", "'")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            .replace("&#x27;", "'")
            .replace("&#x2F;", "/")
            .replace("&#8217;", "’")
            .replace("&#8216;", "‘")
            .replace("&#8220;", "“")
            .replace("&#8221;", "”")
    }
}
