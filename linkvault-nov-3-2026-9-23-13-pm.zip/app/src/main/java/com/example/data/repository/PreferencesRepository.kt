package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode {
    SYSTEM, LIGHT, DARK
}

class PreferencesRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("linkvault_prefs", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(
        ThemeMode.valueOf(prefs.getString("theme_mode", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _amoledMode = MutableStateFlow(prefs.getBoolean("amoled_mode", false))
    val amoledMode: StateFlow<Boolean> = _amoledMode.asStateFlow()

    private val _dynamicColor = MutableStateFlow(prefs.getBoolean("dynamic_color", true))
    val dynamicColor: StateFlow<Boolean> = _dynamicColor.asStateFlow()

    private val _isGridView = MutableStateFlow(prefs.getBoolean("is_grid_view", false))
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _clipboardDetectionEnabled = MutableStateFlow(prefs.getBoolean("clipboard_detect", true))
    val clipboardDetectionEnabled: StateFlow<Boolean> = _clipboardDetectionEnabled.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
        _themeMode.value = mode
    }

    fun setAmoledMode(enabled: Boolean) {
        prefs.edit().putBoolean("amoled_mode", enabled).apply()
        _amoledMode.value = enabled
    }

    fun setDynamicColor(enabled: Boolean) {
        prefs.edit().putBoolean("dynamic_color", enabled).apply()
        _dynamicColor.value = enabled
    }

    fun toggleGridView() {
        val newVal = !_isGridView.value
        prefs.edit().putBoolean("is_grid_view", newVal).apply()
        _isGridView.value = newVal
    }

    fun setClipboardDetection(enabled: Boolean) {
        prefs.edit().putBoolean("clipboard_detect", enabled).apply()
        _clipboardDetectionEnabled.value = enabled
    }
}
