package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.CollectionItem
import com.example.data.model.SavedLink
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [SavedLink::class, CollectionItem::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedLinkDao(): SavedLinkDao
    abstract fun collectionDao(): CollectionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "linkvault_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Initialize default collections without any presaved links
                            CoroutineScope(Dispatchers.IO).launch {
                                populateInitialCollections(getInstance(context))
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateInitialCollections(db: AppDatabase) {
            val now = System.currentTimeMillis()
            val dayMs = 86400000L

            // Starter Collections
            db.collectionDao().insertCollection(
                CollectionItem(name = "Tech & Dev", colorHex = "#006399", iconName = "code", createdAt = now - dayMs * 3)
            )
            db.collectionDao().insertCollection(
                CollectionItem(name = "Creative Inspo", colorHex = "#833AB4", iconName = "brush", createdAt = now - dayMs * 2)
            )
            db.collectionDao().insertCollection(
                CollectionItem(name = "Watch Later", colorHex = "#FF0000", iconName = "play", createdAt = now - dayMs)
            )
            db.collectionDao().insertCollection(
                CollectionItem(name = "Reading List", colorHex = "#10B981", iconName = "book", createdAt = now)
            )
        }
    }
}
