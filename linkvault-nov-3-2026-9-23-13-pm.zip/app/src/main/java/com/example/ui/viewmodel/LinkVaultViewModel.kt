package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.CollectionItem
import com.example.data.model.Platform
import com.example.data.model.SavedLink
import com.example.data.network.MetadataExtractor
import com.example.data.repository.LinkRepository
import com.example.data.repository.PreferencesRepository
import com.example.data.repository.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

enum class SortOrder {
    NEWEST, OLDEST, ALPHABETICAL
}

enum class DateGroup {
    TODAY, YESTERDAY, PREVIOUS_7_DAYS, EARLIER
}

data class SaveDialogState(
    val url: String,
    val title: String,
    val description: String? = null,
    val thumbnailUrl: String? = null,
    val platform: Platform,
    val domain: String,
    val personalNote: String = "",
    val collectionId: Long? = null,
    val isFavorite: Boolean = false,
    val isDuplicate: Boolean = false,
    val existingLinkId: Long? = null,
    val isLoadingMetadata: Boolean = false
)

class LinkVaultViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val repository = LinkRepository(db.savedLinkDao(), db.collectionDao())
    val preferences = PreferencesRepository(application)

    // Navigation Destination State
    private val _currentTab = MutableStateFlow(0) // 0: Home, 1: Collections, 2: Favorites, 3: Settings
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun setCurrentTab(tab: Int) {
        _currentTab.value = tab
    }

    // Search and Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedPlatform = MutableStateFlow<Platform?>(null) // null = All
    val selectedPlatform: StateFlow<Platform?> = _selectedPlatform.asStateFlow()

    private val _sortOrder = MutableStateFlow(SortOrder.NEWEST)
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

    private val _selectedCollectionFilter = MutableStateFlow<Long?>(null)
    val selectedCollectionFilter: StateFlow<Long?> = _selectedCollectionFilter.asStateFlow()

    // Dialog & Detail states
    private val _saveDialogState = MutableStateFlow<SaveDialogState?>(null)
    val saveDialogState: StateFlow<SaveDialogState?> = _saveDialogState.asStateFlow()

    private val _selectedLinkForDetails = MutableStateFlow<SavedLink?>(null)
    val selectedLinkForDetails: StateFlow<SavedLink?> = _selectedLinkForDetails.asStateFlow()

    private val _createCollectionDialogVisible = MutableStateFlow(false)
    val createCollectionDialogVisible: StateFlow<Boolean> = _createCollectionDialogVisible.asStateFlow()

    private val _clipboardDetectedUrl = MutableStateFlow<String?>(null)
    val clipboardDetectedUrl: StateFlow<String?> = _clipboardDetectedUrl.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private var lastDeletedLink: SavedLink? = null

    // Collections Flow
    val collections: StateFlow<List<CollectionItem>> = repository.allCollections
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All links Flow
    val allLinks: StateFlow<List<SavedLink>> = repository.allLinks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalLinksCount: StateFlow<Int> = repository.totalCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Filtered and Sorted links
    val filteredLinks: StateFlow<List<SavedLink>> = combine(
        repository.allLinks,
        _searchQuery,
        _selectedPlatform,
        _sortOrder,
        _selectedCollectionFilter
    ) { links, query, platform, sort, collectionId ->
        var list = links

        // 1. Filter by Collection if active
        if (collectionId != null) {
            list = list.filter { it.collectionId == collectionId }
        }

        // 2. Filter by Platform if active
        if (platform != null) {
            list = list.filter { it.platform.equals(platform.name, ignoreCase = true) || it.platform.equals(platform.displayName, ignoreCase = true) }
        }

        // 3. Filter by Search Query
        if (query.isNotBlank()) {
            val q = query.trim().lowercase(Locale.ROOT)
            list = list.filter {
                it.title.lowercase(Locale.ROOT).contains(q) ||
                it.url.lowercase(Locale.ROOT).contains(q) ||
                it.domain.lowercase(Locale.ROOT).contains(q) ||
                (it.personalNote?.lowercase(Locale.ROOT)?.contains(q) == true) ||
                (it.description?.lowercase(Locale.ROOT)?.contains(q) == true)
            }
        }

        // 4. Sort
        when (sort) {
            SortOrder.NEWEST -> list.sortedByDescending { it.createdAt }
            SortOrder.OLDEST -> list.sortedBy { it.createdAt }
            SortOrder.ALPHABETICAL -> list.sortedBy { it.title.lowercase(Locale.ROOT) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorites Flow
    val favoriteLinks: StateFlow<List<SavedLink>> = repository.favoriteLinks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Grouping by Date
    fun groupLinksByDate(links: List<SavedLink>): Map<DateGroup, List<SavedLink>> {
        val calendar = Calendar.getInstance()
        // Midnight today
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val midnightToday = calendar.timeInMillis

        val midnightYesterday = midnightToday - 86400000L
        val sevenDaysAgo = midnightToday - (86400000L * 7)

        val groups = linkedMapOf<DateGroup, MutableList<SavedLink>>()
        groups[DateGroup.TODAY] = mutableListOf()
        groups[DateGroup.YESTERDAY] = mutableListOf()
        groups[DateGroup.PREVIOUS_7_DAYS] = mutableListOf()
        groups[DateGroup.EARLIER] = mutableListOf()

        for (link in links) {
            when {
                link.createdAt >= midnightToday -> groups[DateGroup.TODAY]?.add(link)
                link.createdAt >= midnightYesterday -> groups[DateGroup.YESTERDAY]?.add(link)
                link.createdAt >= sevenDaysAgo -> groups[DateGroup.PREVIOUS_7_DAYS]?.add(link)
                else -> groups[DateGroup.EARLIER]?.add(link)
            }
        }
        return groups.filterValues { it.isNotEmpty() }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectPlatform(platform: Platform?) {
        _selectedPlatform.value = platform
    }

    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
    }

    fun filterByCollection(collectionId: Long?) {
        _selectedCollectionFilter.value = collectionId
    }

    fun openLinkDetails(link: SavedLink) {
        _selectedLinkForDetails.value = link
    }

    fun closeLinkDetails() {
        _selectedLinkForDetails.value = null
    }

    fun setCreateCollectionDialogVisible(visible: Boolean) {
        _createCollectionDialogVisible.value = visible
    }

    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    // Handles incoming shared link or manual entry
    fun handleIncomingUrl(rawUrl: String) {
        val detectedUrls = Platform.extractUrls(rawUrl)
        val url = if (detectedUrls.isNotEmpty()) detectedUrls.first() else rawUrl.trim()
        if (url.isBlank()) return

        val platform = Platform.fromUrl(url)
        val domain = Platform.extractDomain(url)

        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.findExistingLink(url)
            val initialState = SaveDialogState(
                url = url,
                title = existing?.title ?: domain.replaceFirstChar { it.uppercase() },
                description = existing?.description,
                thumbnailUrl = existing?.thumbnailUrl,
                platform = platform,
                domain = domain,
                personalNote = existing?.personalNote ?: "",
                collectionId = existing?.collectionId ?: _selectedCollectionFilter.value,
                isFavorite = existing?.isFavorite ?: false,
                isDuplicate = existing != null,
                existingLinkId = existing?.id,
                isLoadingMetadata = true
            )
            _saveDialogState.value = initialState

            // Extract metadata asynchronously
            val meta = MetadataExtractor.extract(url)
            val current = _saveDialogState.value
            if (current != null && current.url == url) {
                _saveDialogState.value = current.copy(
                    title = if (current.title == domain || current.title.endsWith(" Link")) meta.title else current.title,
                    description = current.description ?: meta.description,
                    thumbnailUrl = current.thumbnailUrl ?: meta.thumbnailUrl,
                    isLoadingMetadata = false
                )
            }
        }
    }

    fun handleIncomingMultipleUrls(urls: List<String>) {
        if (urls.isEmpty()) return
        // Open the dialog for the first one and save background queued
        handleIncomingUrl(urls.first())
        if (urls.size > 1) {
            viewModelScope.launch(Dispatchers.IO) {
                for (i in 1 until urls.size) {
                    val url = urls[i]
                    val meta = MetadataExtractor.extract(url)
                    val existing = repository.findExistingLink(url)
                    if (existing == null) {
                        repository.saveLink(
                            SavedLink(
                                url = url,
                                title = meta.title,
                                description = meta.description,
                                thumbnailUrl = meta.thumbnailUrl,
                                platform = meta.platform.displayName,
                                domain = meta.domain,
                                collectionId = _selectedCollectionFilter.value
                            )
                        )
                    }
                }
                _snackbarMessage.value = "Saved ${urls.size} shared links to LinkVault"
            }
        }
    }

    fun updateSaveDialogState(transform: (SaveDialogState) -> SaveDialogState) {
        _saveDialogState.value?.let {
            _saveDialogState.value = transform(it)
        }
    }

    fun dismissSaveDialog() {
        _saveDialogState.value = null
    }

    fun confirmSaveDialog() {
        val state = _saveDialogState.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val link = SavedLink(
                id = state.existingLinkId ?: 0,
                url = state.url,
                title = state.title.ifBlank { state.domain },
                description = state.description,
                thumbnailUrl = state.thumbnailUrl,
                platform = state.platform.displayName,
                domain = state.domain,
                personalNote = state.personalNote.takeIf { it.isNotBlank() },
                collectionId = state.collectionId,
                isFavorite = state.isFavorite
            )
            repository.saveLink(link)
            _saveDialogState.value = null
            _snackbarMessage.value = if (state.isDuplicate) "Link updated successfully" else "Saved to LinkVault"
        }
    }

    fun toggleFavorite(link: SavedLink) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleFavorite(link)
            val updated = repository.getLinkById(link.id)
            if (_selectedLinkForDetails.value?.id == link.id) {
                _selectedLinkForDetails.value = updated
            }
        }
    }

    fun updateLinkDetails(link: SavedLink) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateLink(link)
            val updated = repository.getLinkById(link.id)
            _selectedLinkForDetails.value = updated
            _snackbarMessage.value = "Changes saved"
        }
    }

    fun deleteLink(link: SavedLink) {
        viewModelScope.launch(Dispatchers.IO) {
            lastDeletedLink = link
            repository.deleteLink(link)
            if (_selectedLinkForDetails.value?.id == link.id) {
                _selectedLinkForDetails.value = null
            }
            _snackbarMessage.value = "Deleted '${link.title.take(24)}...'"
        }
    }

    fun undoDelete() {
        val toRestore = lastDeletedLink ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveLink(toRestore)
            lastDeletedLink = null
            _snackbarMessage.value = "Restored '${toRestore.title.take(24)}...'"
        }
    }

    fun createCollection(name: String, colorHex: String, iconName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.createCollection(name, colorHex, iconName)
            _createCollectionDialogVisible.value = false
            _snackbarMessage.value = "Collection '$name' created"
        }
    }

    fun deleteCollection(collection: CollectionItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCollection(collection)
            if (_selectedCollectionFilter.value == collection.id) {
                _selectedCollectionFilter.value = null
            }
            _snackbarMessage.value = "Collection '${collection.name}' deleted"
        }
    }

    fun checkClipboardForLink(clipboardText: String?) {
        if (!preferences.clipboardDetectionEnabled.value) return
        val urls = Platform.extractUrls(clipboardText)
        if (urls.isNotEmpty()) {
            val candidate = urls.first()
            viewModelScope.launch(Dispatchers.IO) {
                val existing = repository.findExistingLink(candidate)
                if (existing == null && _saveDialogState.value == null) {
                    _clipboardDetectedUrl.value = candidate
                }
            }
        }
    }

    fun dismissClipboardDetected() {
        _clipboardDetectedUrl.value = null
    }

    fun acceptClipboardDetected() {
        val url = _clipboardDetectedUrl.value ?: return
        _clipboardDetectedUrl.value = null
        handleIncomingUrl(url)
    }

    suspend fun exportJson(): String {
        return repository.exportToJson()
    }

    suspend fun importJson(json: String): Pair<Int, Int> {
        return repository.importFromJson(json)
    }

    fun clearAllData() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllData()
            _snackbarMessage.value = "All LinkVault data cleared"
        }
    }
}
