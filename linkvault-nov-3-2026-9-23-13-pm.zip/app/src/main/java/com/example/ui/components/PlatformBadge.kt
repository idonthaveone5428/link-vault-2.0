package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Platform

@Composable
fun getPlatformIcon(platform: Platform): ImageVector {
    return when (platform) {
        Platform.INSTAGRAM -> Icons.Default.CameraAlt
        Platform.FACEBOOK -> Icons.Default.ThumbUp
        Platform.YOUTUBE -> Icons.Default.PlayArrow
        Platform.REDDIT -> Icons.Default.Forum
        Platform.X -> Icons.Default.Close
        Platform.PINTEREST -> Icons.Default.PinDrop
        Platform.OTHER -> Icons.Default.Language
    }
}

@Composable
fun PlatformBadge(
    platform: Platform,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true
) {
    val icon = getPlatformIcon(platform)
    val color = platform.badgeColor

    Box(
        modifier = modifier
            .testTag("platform_badge_${platform.name.lowercase()}")
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = platform.displayName,
                tint = color,
                modifier = Modifier.size(14.dp)
            )
            if (showLabel) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = platform.displayName,
                    color = color,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
