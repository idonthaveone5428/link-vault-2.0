package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import coil.compose.SubcomposeAsyncImage
import com.example.data.model.CollectionItem
import com.example.data.model.Platform
import com.example.ui.viewmodel.SaveDialogState

@Composable
fun SaveSharedLinkDialog(
    state: SaveDialogState,
    collections: List<CollectionItem>,
    onUpdateState: ((SaveDialogState) -> SaveDialogState) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    var collectionDropdownExpanded by remember { mutableStateOf(false) }
    var platformDropdownExpanded by remember { mutableStateOf(false) }

    val selectedCollection = collections.find { it.id == state.collectionId }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.94f)
            .heightIn(max = 700.dp)
            .testTag("save_shared_link_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isDuplicate) "Update Saved Link" else "Save to LinkVault",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Loading indicator for metadata fetch
                if (state.isLoadingMetadata) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    )
                }

                // Duplicate warning if URL is already saved
                if (state.isDuplicate) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Duplicate",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "This link is already in your vault! Saving will update your notes and settings.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Thumbnail Preview (if available)
                if (!state.thumbnailUrl.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        SubcomposeAsyncImage(
                            model = state.thumbnailUrl,
                            contentDescription = "Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth(),
                            loading = {
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                }
                            },
                            error = {
                                FallbackThumbnail(platform = state.platform)
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // URL Display
                Text(
                    text = state.url,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(8.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Editable Title
                OutlinedTextField(
                    value = state.title,
                    onValueChange = { newTitle ->
                        onUpdateState { it.copy(title = newTitle) }
                    },
                    label = { Text("Title") },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_dialog_title_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Platform / Category selector & Collection selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Platform Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { platformDropdownExpanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_platform_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            PlatformBadge(platform = state.platform, showLabel = true)
                        }

                        DropdownMenu(
                            expanded = platformDropdownExpanded,
                            onDismissRequest = { platformDropdownExpanded = false }
                        ) {
                            Platform.entries.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.displayName) },
                                    leadingIcon = {
                                        Icon(
                                            getPlatformIcon(p),
                                            contentDescription = null,
                                            tint = p.badgeColor,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    },
                                    onClick = {
                                        onUpdateState { it.copy(platform = p) }
                                        platformDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Collection Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { collectionDropdownExpanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_collection_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = selectedCollection?.name ?: "No Collection",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 12.sp
                            )
                        }

                        DropdownMenu(
                            expanded = collectionDropdownExpanded,
                            onDismissRequest = { collectionDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (Unassigned)") },
                                onClick = {
                                    onUpdateState { it.copy(collectionId = null) }
                                    collectionDropdownExpanded = false
                                }
                            )
                            collections.forEach { col ->
                                DropdownMenuItem(
                                    text = { Text(col.name) },
                                    leadingIcon = {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    try {
                                                        Color(android.graphics.Color.parseColor(col.colorHex))
                                                    } catch (_: Exception) {
                                                        MaterialTheme.colorScheme.primary
                                                    }
                                                )
                                        )
                                    },
                                    onClick = {
                                        onUpdateState { it.copy(collectionId = col.id) }
                                        collectionDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Personal Note
                OutlinedTextField(
                    value = state.personalNote,
                    onValueChange = { newNote ->
                        onUpdateState { it.copy(personalNote = newNote) }
                    },
                    label = { Text("Personal Note (Optional)") },
                    placeholder = { Text("Why are you saving this?") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_dialog_note_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Favorite Toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            onUpdateState { it.copy(isFavorite = !it.isFavorite) }
                        }
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (state.isFavorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Add to Favorites", fontSize = 14.sp)
                    }
                    Switch(
                        checked = state.isFavorite,
                        onCheckedChange = { checked ->
                            onUpdateState { it.copy(isFavorite = checked) }
                        },
                        modifier = Modifier.testTag("save_dialog_fav_switch")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("save_dialog_confirm_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (state.isDuplicate) "Update" else "Save to Vault")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("save_dialog_cancel_button")
            ) {
                Text("Cancel")
            }
        }
    )
}
