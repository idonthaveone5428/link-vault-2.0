package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.Platform

@Composable
fun CategoryChips(
    selectedPlatform: Platform?,
    onPlatformSelected: (Platform?) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .testTag("category_filter_chips_row")
            .horizontalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // "All" Chip
        val isAllSelected = selectedPlatform == null
        FilterChip(
            selected = isAllSelected,
            onClick = { onPlatformSelected(null) },
            label = { Text("All") },
            leadingIcon = if (isAllSelected) {
                {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        modifier = Modifier.size(16.dp)
                    )
                }
            } else null,
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier.testTag("chip_all")
        )

        // Platform Chips
        Platform.entries.forEach { platform ->
            val isSelected = selectedPlatform == platform
            FilterChip(
                selected = isSelected,
                onClick = {
                    if (isSelected) onPlatformSelected(null) else onPlatformSelected(platform)
                },
                label = { Text(platform.displayName) },
                leadingIcon = {
                    Icon(
                        imageVector = getPlatformIcon(platform),
                        contentDescription = platform.displayName,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else platform.badgeColor,
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier.testTag("chip_${platform.name.lowercase()}")
            )
        }
    }
}
