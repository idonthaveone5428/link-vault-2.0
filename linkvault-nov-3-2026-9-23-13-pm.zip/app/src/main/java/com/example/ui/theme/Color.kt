package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Tones
val PrimaryLight = Color(0xFF006399)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFCDE5FF)
val OnPrimaryContainerLight = Color(0xFF001D32)

val SecondaryLight = Color(0xFF51606F)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD4E4F6)
val OnSecondaryContainerLight = Color(0xFF0E1D2A)

val TertiaryLight = Color(0xFF6B5778)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFF3DAFF)
val OnTertiaryContainerLight = Color(0xFF251432)

val BackgroundLight = Color(0xFFF8F9FF)
val OnBackgroundLight = Color(0xFF191C20)
val SurfaceLight = Color(0xFFFAF9FD)
val OnSurfaceLight = Color(0xFF191C20)
val SurfaceVariantLight = Color(0xFFDEE3EB)
val OnSurfaceVariantLight = Color(0xFF42474E)

// Dark Theme Tones
val PrimaryDark = Color(0xFF94CCFF)
val OnPrimaryDark = Color(0xFF003352)
val PrimaryContainerDark = Color(0xFF004B74)
val OnPrimaryContainerDark = Color(0xFFCDE5FF)

val SecondaryDark = Color(0xFFB8C8D9)
val OnSecondaryDark = Color(0xFF233240)
val SecondaryContainerDark = Color(0xFF3A4857)
val OnSecondaryContainerDark = Color(0xFFD4E4F6)

val TertiaryDark = Color(0xFFD7BEE4)
val OnTertiaryDark = Color(0xFF3B2948)
val TertiaryContainerDark = Color(0xFF533F5F)
val OnTertiaryContainerDark = Color(0xFFF3DAFF)

val BackgroundDark = Color(0xFF101418)
val OnBackgroundDark = Color(0xFFE0E2E8)
val SurfaceDark = Color(0xFF111418)
val OnSurfaceDark = Color(0xFFE0E2E8)
val SurfaceVariantDark = Color(0xFF42474E)
val OnSurfaceVariantDark = Color(0xFFC2C7CF)

// AMOLED Black Theme Tones
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF080808)
val AmoledSurfaceVariant = Color(0xFF16181B)

// Platform Specific Accents
val InstagramPink = Color(0xFFE1306C)
val InstagramPurple = Color(0xFF833AB4)
val YouTubeRed = Color(0xFFFF0000)
val TikTokBlack = Color(0xFF00F2FE)
val TikTokRed = Color(0xFFFE2C55)
val FacebookBlue = Color(0xFF1877F2)
val RedditOrange = Color(0xFFFF4500)
val XBlack = Color(0xFF14171A)
val XLight = Color(0xFFFFFFFF)
val PinterestRed = Color(0xFFBD081C)
val OtherGreen = Color(0xFF10B981)
