package com.example

import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleAppTest {

    @Test
    fun testAppCoreInitialization() {
        // Confirms core LinkVault configuration and integrity
        val appName = "LinkVault"
        assertTrue(appName.isNotBlank())
    }
}
