package com.example

import com.example.data.model.Platform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testUrlExtractionFromSharedText() {
        val sharedText = "Look at this amazing recipe on Instagram: https://www.instagram.com/reel/C8xyz123/ hope you like it!"
        val urls = Platform.extractUrls(sharedText)
        assertEquals(1, urls.size)
        assertEquals("https://www.instagram.com/reel/C8xyz123/", urls.first())
    }

    @Test
    fun testMultipleUrlExtraction() {
        val text = "First video: https://youtu.be/abc12345678 and second link: https://tiktok.com/@chef/video/999"
        val urls = Platform.extractUrls(text)
        assertEquals(2, urls.size)
        assertEquals("https://youtu.be/abc12345678", urls[0])
        assertEquals("https://tiktok.com/@chef/video/999", urls[1])
    }

    @Test
    fun testPlatformDetectionFromDomain() {
        assertEquals(Platform.INSTAGRAM, Platform.fromUrl("https://instagram.com/p/123"))
        assertEquals(Platform.INSTAGRAM, Platform.fromUrl("https://www.instagram.com/reel/xyz/"))
        assertEquals(Platform.FACEBOOK, Platform.fromUrl("https://fb.watch/abcd/"))
        assertEquals(Platform.FACEBOOK, Platform.fromUrl("https://www.facebook.com/watch/?v=123"))
        assertEquals(Platform.YOUTUBE, Platform.fromUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals(Platform.YOUTUBE, Platform.fromUrl("https://youtu.be/dQw4w9WgXcQ"))
        assertEquals(Platform.REDDIT, Platform.fromUrl("https://www.reddit.com/r/androiddev/comments/123/"))
        assertEquals(Platform.REDDIT, Platform.fromUrl("https://redd.it/123"))
        assertEquals(Platform.X, Platform.fromUrl("https://twitter.com/android/status/123"))
        assertEquals(Platform.X, Platform.fromUrl("https://x.com/android/status/123"))
        assertEquals(Platform.PINTEREST, Platform.fromUrl("https://www.pinterest.com/pin/12345/"))
        assertEquals(Platform.PINTEREST, Platform.fromUrl("https://pin.it/abc12"))
        assertEquals(Platform.OTHER, Platform.fromUrl("https://github.com/torvalds/linux"))
        assertEquals(Platform.OTHER, Platform.fromUrl("https://developer.android.com/"))
    }

    @Test
    fun testDomainExtraction() {
        assertEquals("youtube.com", Platform.extractDomain("https://www.youtube.com/watch?v=123"))
        assertEquals("instagram.com", Platform.extractDomain("https://instagram.com/reel/xyz/"))
        assertEquals("github.com", Platform.extractDomain("https://github.com/trending"))
    }
}
